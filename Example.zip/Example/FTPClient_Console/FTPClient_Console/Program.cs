﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace FTPClient_ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //string hosname = "ftp://192.168.26.1";
            //string path = hosname + "/assests";


            FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://10.60.254.63"); // tạo kết nối

            NetworkCredential credential = new NetworkCredential("anonymous", ""); // nhập mật khẩu

            request.Credentials = credential;
            request.Method = WebRequestMethods.Ftp.ListDirectoryDetails;

            FtpWebResponse response = (FtpWebResponse)request.GetResponse();

            Stream responeStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responeStream);

            string data = reader.ReadToEnd();
            Console.WriteLine(data);

            reader.Close();
            response.Close();

            Console.ReadKey();


        }
    }
}
