﻿using System;
using System.Collections.Generic;
using System.IO;   //thiss for file class
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileClass_Console
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"D:\\a.txt";

            //check exist
            if (File.Exists(filePath))
            {
                Console.WriteLine("Ok");
            }
            else
            {
                Console.WriteLine("No");
            }
            //write text
            string content = "Say hello";
            File.WriteAllText(filePath, content);

            //read text
            string text = File.ReadAllText(filePath);
            Console.WriteLine(text);

            ////read file to byte[]
            //byte[] byteData = File.ReadAllBytes(filePath); //readallbyte doc du lieu dang byte nen phai khoi tao byte

            ////Send byteData via Network and write to computer
            //File.WriteAllBytes(@"D:\b.txt", byteData);

            Console.ReadKey();
        }
    }
}
