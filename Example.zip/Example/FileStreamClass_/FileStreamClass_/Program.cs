﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileStreamClass_Console
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"D:\a.txt";

            //Read byte[] from file
            
            //using (FileStream fs = new FileStream(filePath, FileMode.Open))
            ////using (FileStream fs = File.OpenRead(filePath))
            //{
            //    UTF8Encoding temp = new UTF8Encoding(true);

            //    int length = 0;              
            //    byte[] readData = new byte[1024];
            //    while ((length = fs.Read(readData, 0, readData.Length)) > 0 )
            //    {
            //        Console.WriteLine(temp.GetString(readData));
            //    }

            //}

            //Write byte[] to file
            try
            {
                FileStream fs = File.OpenWrite(filePath);
                Console.Write("Input text: ");
                string text = Console.ReadLine();

                UTF8Encoding temp = new UTF8Encoding(true);
                byte[] buffer = temp.GetBytes(text);

                fs.Write(buffer, 0, buffer.Length);

            } catch (Exception ex) { }



            Console.ReadKey();
        }
    }
}
