﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Net.Http;

namespace HTTPOverTCPConsole
{
    internal class Program
    {
        static async Task Main(string[] args) //trên thì sài void, dưới sài task
        {
            //Uri uri = new Uri("http://example.com");
          

          
//                byte[] requestBytes = Encoding.ASCII.GetBytes($@"GET {uri.AbsoluteUri} HTTP/1.0
//Host: {uri.Host}
//Connection: Close

//");
//            TcpClient tcpClient = new TcpClient(uri.Host, 80);

//            NetworkStream stream = tcpClient.GetStream();
//            stream.Write(requestBytes, 0, requestBytes.Length);

//            byte[] response = new byte[4096];
//            while (true)
//            {
//                int readData = stream.Read(response, 0, response.Length);
//                if(readData == 0)
//                {
//                    break;
//                }
//                Console.WriteLine(Encoding.ASCII.GetString(response, 0, readData));
//            }
//            stream.Close(); 
//            tcpClient.Close();


            HttpClient client = new HttpClient();

            //Cách 1: lấy dữ liệu nhanh
            string body = await client.GetStringAsync("http://example.com/");

            //----------------------------------------------------------------

            //cách 2: lấy dữ liệu từng phần có thể dẽ dàng tách 
            //HttpResponseMessage reponse = await client.GetAsync("http://10.10.125.244/cse306");
            //reponse.EnsureSuccessStatusCode();
            //string body = await reponse.Content.ReadAsStringAsync();

            //----------------------------------------------------------------

            //Cách 3
            //Dictionary<string, string> values = new Dictionary<string, string>()
            //{
            //    {"type", "string"},
            //    //{" param2", "param2_value}
            //};
            //FormUrlEncodedContent content = new FormUrlEncodedContent(values);
            //HttpResponseMessage reponse = await client.PostAsync("http://10.10.125.244/cse306/index.php", content);
            //string body = await reponse.Content.ReadAsStringAsync();


            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine(body);

            Console.ReadKey();
        }
    }
}
