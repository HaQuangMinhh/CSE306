﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace RSAConsoleApp
{
    internal class Program
    {
      
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;

            string data = "Hello, khiim";
            byte[] bytes = Encoding.UTF8.GetBytes(data);
            byte[] encryptedData;

        
            RSAParameters rsaParameters;

            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider()) 
            {
                rsaParameters =  rsa.ExportParameters(true);  //lấy private key sài true
                encryptedData = rsa.Encrypt(bytes, false);  //nếu k đủ độ dài yêu cầu thì tự bổ sung thêm
            }

            Console.WriteLine(Encoding.UTF8.GetString(encryptedData));

            byte[] decryptedData;
            using(RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
            {
                rsa.ImportParameters(rsaParameters);
                decryptedData = rsa.Decrypt(encryptedData, false);
            }
            Console.WriteLine(Encoding.UTF8.GetString(decryptedData));
            //in ra 2 dòng 1 mã hóa, 1 giải mã

            Console.ReadKey();


        }
    }
}
