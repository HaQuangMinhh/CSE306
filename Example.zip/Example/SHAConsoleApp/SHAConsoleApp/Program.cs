﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SHAConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string password = "246357";
            byte[] data = Encoding.UTF8.GetBytes(password);
            byte[] hashedData;

            using (SHA256 sHA256 = SHA256.Create())
            {
                hashedData = sHA256.ComputeHash(data);
            }

            StringBuilder stringBuilder = new StringBuilder();

            for (int i = 0; i< hashedData.Length; i++)
            {
                stringBuilder.Append(hashedData[i].ToString("x2"));
            }

            Console.WriteLine(stringBuilder.ToString());
            Console.ReadKey();
        }
    }
}
