﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;

namespace SendMailConsole
{
    internal class Program
    {
        static void Main(string[] args)
        { //Nhập tên ứng dụng bạn muốn tạo mật khẩu (ví dụ: "Email SMTP").
            //https://myaccount.google.com/apppasswords
            NetworkCredential myCredential = new NetworkCredential("khiem.ngo.cit20@eiu.edu.vn", "bbpi gyzi jcma qyxw");

            SmtpClient client = new SmtpClient();
            client.Host = "smtp.gmail.com";
            client.Port = 587;
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = myCredential;

            MailAddress from = new MailAddress("khiem.ngo.cit20@eiu.edu.vn", "Khiem");
            MailAddress to = new MailAddress("khiemkhanhkhai@gmail.com");

            MailMessage message = new MailMessage(from, to);

            message.Subject = "hello thay";
            message.Body = "This is my content";

            client.Send(message);
            message.Dispose();
            Console.WriteLine("Done");
        }
    }
}
