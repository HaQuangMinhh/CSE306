﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace SerializationConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            student.Id = 1;
            student.Name = "test";

            string json = JsonSerializer.Serialize(student);
            Console.WriteLine(json);

            Student student2 = JsonSerializer.Deserialize<Student>(json);
            Console.WriteLine(student2.Id.ToString());
            Console.WriteLine(student2.Name);
            Console.ReadLine();

        }
    }
}
