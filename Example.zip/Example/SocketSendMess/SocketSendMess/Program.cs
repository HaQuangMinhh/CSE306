﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace SocketSendMess
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Socket sk = new Socket(SocketType.Stream, ProtocolType.Tcp);
            sk.Connect(IPAddress.Parse("10.60.251.98"), 30000);

            string name = "Khiem";
            byte[] data = Encoding.UTF8.GetBytes(name);

            int byteSent = 0;
            while (byteSent < data.Length)
            {
                byteSent += sk.Send(data,byteSent,data.Length - byteSent, SocketFlags.None);
            } 

            //sk.Send(data);


            sk.Close();
        }
    }
}
