﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace TCPClient_Class
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TcpClient tcpClient = new TcpClient();
            tcpClient.Connect(IPAddress.Parse("10.60.250.122"), 30000); //ip máy ng nhận

            NetworkStream stream = tcpClient.GetStream();

            byte[] buffer = Encoding.UTF8.GetBytes("Khiem");

            stream.Write(buffer, 0, buffer.Length);

            stream.Close();
            tcpClient.Close();
        }
    }
}
