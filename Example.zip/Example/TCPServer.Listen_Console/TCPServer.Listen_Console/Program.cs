﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace TCPServer.Listen_Console
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TcpListener tcp = new TcpListener(IPAddress.Parse("10.60.254.63"), 30000); //ip máy mình
            tcp.Start();

            while (true)
            {
                Console.WriteLine("Waiting for connection..");
                TcpClient client = tcp.AcceptTcpClient();

                NetworkStream ns = client.GetStream();

                byte[] buffer = new byte[1024]; 
                int bytesRead = 0;

                while (true)
                {
                    bytesRead = ns.Read(buffer, 0, buffer.Length);
                    if( bytesRead == 0 ) break;
                    Console.WriteLine(Encoding.UTF8.GetString(buffer, 0, bytesRead));  
                    
                }
                ns.Close();
                client.Close();
            }

        }
    }
}
