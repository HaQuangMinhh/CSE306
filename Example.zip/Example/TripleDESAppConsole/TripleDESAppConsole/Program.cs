﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace TripleDESAppConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            byte[] key;
            byte[] iv;

            string plainText = "This is my content";

            //Encryted
            using (TripleDES tripleDes = TripleDES.Create())
            {
                key = tripleDes.Key;
                iv = tripleDes.IV;

                using (FileStream fStream = File.Open("encrypted.txt", FileMode.Create))
                using (ICryptoTransform encryptor = tripleDes.CreateEncryptor(key, iv))
                using ( var cStream = new CryptoStream(fStream, encryptor, CryptoStreamMode.Write))
                {
                    //Convert the provided string to a byte arrray
                    byte[] toEncrypt = Encoding.UTF8.GetBytes(plainText);
                    
                    //write the byte array to the crytop stream
                    cStream.Write(toEncrypt, 0, toEncrypt.Length);
                }
             }

            //Decrypted
            string decryptedText;
            using (FileStream fStream = File.OpenRead("encrypted.txt"))
            using (TripleDES tripleDes = TripleDES.Create())
            using (ICryptoTransform decryptor = tripleDes.CreateDecryptor(key, iv))
            using (var cStream = new CryptoStream(fStream, decryptor, CryptoStreamMode.Read))
            using (StreamReader reader = new StreamReader(cStream, Encoding.UTF8))
            {
                decryptedText = reader.ReadToEnd();
            }
            Console.WriteLine(decryptedText);
            Console.ReadKey();

        }
    }
}
